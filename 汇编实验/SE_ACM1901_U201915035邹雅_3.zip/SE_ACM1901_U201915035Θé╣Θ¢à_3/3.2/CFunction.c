#include <stdio.h>
#include<string.h>

typedef struct GOODS
{
	char GOODSNAME[10];
	short BUYPRICE;
	short SELLPRICE;
	short BUYNUM;
	short SELLNUM;
	short RATE;
}GOODS;


int Login(char* correctName,char* correctPass) {
	char name[10];
	char pass[20];
	printf("PLEASE INPUT YOUR NAME\n");
	scanf_s("%s", name,10);
	printf("PLEASE INPUT YOUR PASSWORD\n");
	scanf_s("%s", pass,20);
	if (strcmp(name, correctName) != 0) {
		printf("WRONG NAME\n");
		return -1;
	}
	if (strcmp(pass, correctPass) != 0) {
		printf("WRONG PASSWORD\n");
		return -1;
	}
	return 0;
}
void ShowMenu() {
	printf("*****WELCOME TO SHOP*****\n");
	printf("1.Search the goods\n");
	printf("2.Sell the goods\n");
	printf("3.Add the goods\n");
	printf("4.Calculate the rate of profit\n");
	printf("5.Show goods refer to the rate of profit\n");
	printf("6.Add new good to shop\n");
	printf("9.Exit\n");
}
void NewGoodToSystem(GOODS* curGood) {
	printf("Input the name of good you want add\n");
	scanf_s("%s", &curGood->GOODSNAME,10);
	printf("Input buy price \n");
	scanf_s("%hd", &curGood->BUYPRICE);
	printf("Input sell price \n");
	scanf_s("%hd", &curGood->SELLPRICE);
	printf("Input buy number \n");
	scanf_s("%hd", &curGood->BUYNUM);
	printf("Input sell number\n");
	scanf_s("%hd", &curGood->SELLNUM);
}

